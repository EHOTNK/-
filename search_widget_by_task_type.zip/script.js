define(['jquery'], function ($) {
	var CustomWidget = function () {
		var self = this;
		this.RenderSearch = function () {
			if ($('.card-task__types').length === 0) {
				return;
			}
			else if ($('.search_client_class').length === 0) {
				var clientList = $(".card-task__types");
				$(clientList).prepend(`<input class="search_client_class" style=" 
				text-align:center; color:black;    background:#e0e0e0; line-height: 39px;
			   width: 201.19px; border-radius: 5px;" placeholder="Поиск...">`);
			}
			self.AddSearchEventListener();
		}
		this.AddSearchEventListener = function () {
			var SearchField = $('input[class = "search_client_class"]');
			$(SearchField).keyup(self.DoSearch).change(self.DoSearch);
		}
		this.DoSearch = function (event) {

			var SearchField = $('input[class = "search_client_class"]');
			if ($(SearchField).val() != "" && $(SearchField).val().length > 2) {
				var InputNameArr = $(SearchField).val().toLowerCase().split('');
				var a = AMOCRM.constant('task_types')
				Object.keys(a).forEach(function (value) {
					var text = a[value].option;
					var id = a[value].id;
					var regex = /<span(?:.*?)><\/span>(.*?)$/gm;
					var Name = regex.exec(text);
					var NameLowerCase = Name[1].toLowerCase();
					var NameArr = NameLowerCase.split('');
					for (var i = 0; i < $(SearchField).val().length; i++) {
						if (InputNameArr[i] != NameArr[i]) {
							$(`input[value="${id}"]`).parent().hide();
							break;
						}
						else { $(`input[value="${id}"]`).parent().show() }
					}
				})
			}
			else {
				var a = AMOCRM.constant('task_types')
				Object.keys(a).forEach(function (value) {
					var id = a[value].id;
					$(`input[value="${id}"]`).parent().show()
				})
			}
		}
		this.callbacks = {
			render: function () {
				var targetNodes = $(".feed-compose")
				var MutationObserver = window.MutationObserver || window.WebKitMutationObserver
				var myObserver = new MutationObserver(mutationHandler)
				var obsConfig = {
					childList: true,
					characterData: true,
					attributes: false,
					subtree: true
				}


				targetNodes.each(function () {
					myObserver.observe(this, obsConfig);
				});

				function mutationHandler(mutationRecords) {
					self.RenderSearch();

				}
				console.log('render');
				return true;
			},
			init: function () {

				console.log('init');
				return true;
			},
			bind_actions: function () {
				console.log('bind_actions');
				return true;
			},
			settings: function () {
				return true;
			},
			onSave: function () {
				alert('click');
				return true;
			},
			destroy: function () {

			},
			contacts: {
				//select contacts in list and clicked on widget name
				selected: function () {
					console.log('contacts');
				}
			},
			leads: {
				//select leads in list and clicked on widget name
				selected: function () {
					console.log('leads');
				}
			},
			tasks: {
				//select taks in list and clicked on widget name
				selected: function () {
					console.log('tasks');
				}
			}
		};
		return this;
	};

	return CustomWidget;
});